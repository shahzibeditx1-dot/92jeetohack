package com.example.pakvip

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs

/** A layout that can be dragged anywhere; taps still reach the children. */
class DraggableFrame(context: Context) : FrameLayout(context) {
    private var downX = 0f
    private var downY = 0f
    private var startX = 0f
    private var startY = 0f
    private var dragging = false
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX; downY = ev.rawY
                startX = x; startY = y
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && (abs(ev.rawX - downX) > slop || abs(ev.rawY - downY) > slop)) {
                    dragging = true
                }
            }
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX; downY = ev.rawY
                startX = x; startY = y
            }
            MotionEvent.ACTION_MOVE -> {
                val p = parent as? View
                var nx = startX + (ev.rawX - downX)
                var ny = startY + (ev.rawY - downY)
                if (p != null) {
                    nx = nx.coerceIn(0f, (p.width - width).toFloat().coerceAtLeast(0f))
                    ny = ny.coerceIn(0f, (p.height - height).toFloat().coerceAtLeast(0f))
                }
                x = nx; y = ny
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }
}

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private lateinit var loginPopup: FrameLayout
    private lateinit var fab: DraggableFrame
    private lateinit var panelBox: DraggableFrame
    private val handler = Handler(Looper.getMainLooper())

    private val REGISTER =
        "https://www.pakvip.co/#/register?invitationCode=17561101154"

    // Panel size in dp. If the panel looks cut off, raise PANEL_H_DP.
    private val PANEL_W_DP = 200
    private val PANEL_H_DP = 360
    private val FAB_DP = 52

    private val GAME =
        "https://pakvip.co/#/saasLottery/WinGo?gameCode=WinGo_30S&lottery=WinGo"

    private lateinit var panelWeb: WebView
    private var panelPage = ""
    private var panelOpen = false
    private var lastOnRegister = false

    private val prefs by lazy { getSharedPreferences("pakvip", MODE_PRIVATE) }
    private var registered: Boolean
        get() = prefs.getBoolean("registered", false)
        set(v) { prefs.edit().putBoolean("registered", v).apply() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)

        // 1. Main website
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    val url = request.url.toString()
                    if (!url.contains("pakvip.co")) return true
                    if (!registered && url.contains("#/login")) {
                        refreshUi(url)
                        return true
                    }
                    return false
                }
            }
            loadUrl(REGISTER)
        }
        root.addView(webView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        // 2. Draggable panel (your HTML design)
        panelBox = DraggableFrame(this).apply { visibility = View.GONE }
        val pv = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    val u = request.url.toString()
                    if (u.startsWith("http")) {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
                        return true
                    }
                    return false
                }
            }
        }
        panelWeb = pv
        panelBox.addView(pv, FrameLayout.LayoutParams(dp(PANEL_W_DP), dp(PANEL_H_DP)))
        root.addView(panelBox, FrameLayout.LayoutParams(dp(PANEL_W_DP), dp(PANEL_H_DP)))

        // 3. Draggable floating icon
        fab = DraggableFrame(this)
        val icon = ImageView(this).apply {
            setBackgroundResource(R.drawable.fab_bg)
            setImageResource(R.drawable.ic_crown)
            setPadding(dp(11), dp(11), dp(11), dp(11))
            setOnClickListener { openPanel() }
        }
        fab.addView(icon, FrameLayout.LayoutParams(dp(FAB_DP), dp(FAB_DP)))
        root.addView(fab, FrameLayout.LayoutParams(dp(FAB_DP), dp(FAB_DP)))

        // 4. Small login popup
        loginPopup = buildLoginPopup()
        loginPopup.visibility = View.GONE
        root.addView(loginPopup, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        setContentView(root)

        root.post {
            fab.x = (root.width - dp(FAB_DP) - dp(12)).toFloat()
            fab.y = root.height * 0.55f
            panelBox.x = ((root.width - dp(PANEL_W_DP)) / 2).toFloat()
            panelBox.y = dp(60).toFloat()
            refreshUi(webView.url)
        }

        // Light polling to catch SPA hash changes
        handler.post(object : Runnable {
            override fun run() {
                refreshUi(webView.url)
                handler.postDelayed(this, 300)
            }
        })
    }

    inner class Bridge {
        @JavascriptInterface
        fun register() {
            runOnUiThread {
                loginPopup.visibility = View.GONE
                closePanel()
                webView.loadUrl(REGISTER)
            }
        }

        @JavascriptInterface
        fun openGame() {
            runOnUiThread {
                closePanel()
                webView.loadUrl(GAME)
            }
        }

        @JavascriptInterface
        fun hide() {
            runOnUiThread { closePanel() }
        }
    }

    private fun openPanel() { panelOpen = true; refreshUi(webView.url) }
    private fun closePanel() { panelOpen = false; refreshUi(webView.url) }

    private fun refreshUi(url: String?) {
        if (url != null) {
            val onRegister = url.contains("#/register")
            val onLogin = url.contains("#/login")
            // Moving from the register page to a normal page means registration is done
            if (lastOnRegister && !onRegister && !onLogin && url.contains("pakvip.co") && !registered) {
                registered = true
            }
            lastOnRegister = onRegister
            loginPopup.visibility = if (!registered && onLogin) View.VISIBLE else View.GONE
        }
        // panel.html = before register
        // panel2.html = after register (Open WinGo)
        // panel3.html = when WinGo game page is open (predictor HUD)
        val onWinGo = url != null && (
            url.contains("WinGo", ignoreCase = true) ||
            url.contains("saasLottery", ignoreCase = true)
        )
        val page = when {
            !registered -> "panel.html"
            onWinGo -> "panel3.html"
            else -> "panel2.html"
        }
        if (page != panelPage) {
            panelPage = page
            panelWeb.loadUrl("file:///android_asset/" + page)
        }
        panelBox.visibility = if (panelOpen) View.VISIBLE else View.GONE
        fab.visibility = if (panelOpen) View.GONE else View.VISIBLE
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildLoginPopup(): FrameLayout {
        val pw = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/popup.html")
        }
        return FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#99000000"))
            isClickable = true
            addView(pw, FrameLayout.LayoutParams(dp(300), dp(330), Gravity.CENTER))
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            panelOpen -> closePanel()
            webView.canGoBack() -> webView.goBack()
            else -> super.onBackPressed()
        }
    }
}
